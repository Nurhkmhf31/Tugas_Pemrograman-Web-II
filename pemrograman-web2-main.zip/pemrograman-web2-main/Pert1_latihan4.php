<!-- Konstanta -->
<?php
    define("Judul", "Menghitung Luas Lingkaran");
    define("phi", 3.14);
    $r = 5;
    $luas = phi*$r*$r;
    echo Judul;
    echo "Luas = $luas";
?>
