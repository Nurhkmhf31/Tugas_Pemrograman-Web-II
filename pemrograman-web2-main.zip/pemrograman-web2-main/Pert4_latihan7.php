<!DOCTYPE html>
<html>
<head>
<title>Penggunaan For</title>
</head>
<body>
<?Php
For ($bil = 1; $bil<25; $bil++)
Print("$bil<br>\n");
?>
</body>
</html>
