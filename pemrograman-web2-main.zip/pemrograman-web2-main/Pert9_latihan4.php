<HTML>
<HEAD>
<TITLE> Tanggal </TITLE>
</HEAD>
<BODY>
<font size="10px"> 
<?php
echo "Sekarang tanggal ";
echo date('d-F-Y');
echo "<br>dan jam ";
echo date('h:i:s A');
?>
</FONT>
</BODY>
</HTML>