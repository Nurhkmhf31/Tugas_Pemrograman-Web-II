<?php
$a[0] =1;
$a[1] =3;
$a[2] =5;
$jumlah =count($a);
print "Jumlah array a = $jumlah <br>";
// variabel $jumlah akan bernilai 3
$b["buah"] = "semangka";
$b["sayur"] ="wortel";
$b["daging"] ="ayam";
$b["utama"] ="nasi";
$jumlah = sizeof($b);
print "Jumlah array b = $jumlah <br>";
// variabel $jumlah akan bernilai 4
?>