<?php
 $a = 1;
 $b = 2;
 $c = $a.$b;
 //nilai $c sekarang 12, menggabungkan angka 1 dan 2
 $d= $c + 1 ;
 echo $d;
 // nilai $d 13,
 $e = "Number";
 $f = $e.$d;
 echo $f;
 //nilai $f menjadi Number13, a kombinasi $e dan $f
 ?> 
