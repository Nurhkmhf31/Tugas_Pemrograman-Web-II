<?php
function basic($argument)
{
echo $argument;
}
basic('hello world!'); // outputs 'hello world!'
?>